package responses.lessons;

public class AddLessonResponse {

    private long id;

    public AddLessonResponse(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
