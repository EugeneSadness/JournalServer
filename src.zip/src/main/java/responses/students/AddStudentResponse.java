package responses.students;

public class AddStudentResponse {

    private long id;

    public AddStudentResponse(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
