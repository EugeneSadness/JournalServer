package responses.students;

public class DeleteStudentResponse {

}
