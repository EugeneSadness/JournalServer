package responses.subjects;

public class DeleteSubjectResponse {
}
