package requests.groups;

public class GetGroupRequest {

}
