package requests.teachers;

public class EditTeacherRequest {
    private Long id;
    private String lastName;
    private String firstName;
    private String middleName;

    public EditTeacherRequest(Long id, String lastName, String firstName, String middleName) {
        this.id = id;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
    }

    public Long getId() {
        return id;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }
}
