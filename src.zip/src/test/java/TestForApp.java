import controllers.groups.GroupController;
import controllers.students.StudentController;
import entities.Group;
import entities.Student;
import org.junit.Before;
import org.junit.Test;
import repositories.Storage;
import requests.groups.AddGroupRequest;
import requests.groups.DeleteGroupRequest;
import requests.groups.EditGroupRequest;
import requests.groups.GetGroupByIdRequest;
import requests.students.*;
import responses.ResponseEntity;
import responses.groups.AddGroupResponse;
import responses.groups.DeleteGroupResponse;
import responses.groups.EditGroupResponse;
import responses.groups.GetGroupByIdResponse;
import responses.students.AddStudentResponse;
import responses.students.DeleteStudentResponse;
import responses.students.EditStudentResponse;
import responses.students.GetStudentsByGroupResponse;
import services.groups.GroupService;
import services.students.StudentService;

import java.util.ArrayList;

public class TestForApp {

    public Storage storage;

    @Before
    public void init(){
        ///заполним чутка бд
        storage = Storage.getInstance();
        storage.getGroups().put(125L, new Group(125L, "MMB-104"));
        storage.getGroups().put(136L, new Group(136L, "MMB-102"));
        storage.getStudents().put(11L, new Student(11L, 125L, "Ivanov", "Ivan", "Ivanich", "Listed"));
        storage.getStudents().put(12L, new Student(12L, 125L, "Kashov", "Max", "Lebedovich", "UnListed"));
        storage.getStudents().put(16L, new Student(16L, 136L, "Babov", "Alex", "Nikolaich", "Listed"));
    }

    @Test
    public void checkCreates() {
        //Просмотрим create , заодно и ResponseEntity
        ArrayList<ResponseEntity<AddStudentResponse>> arrayOfStudents = new ArrayList<>();
        StudentController studentController = new StudentController(storage);
        GroupController groupController = new GroupController(storage);
        ResponseEntity<AddGroupResponse> responseEntityGroup = groupController.addGroup(new AddGroupRequest("MMB-101"));
        arrayOfStudents.add(studentController.addStudent(
                new AddStudentRequest("Hopov", "Hop", "Hopovich", responseEntityGroup.getResp().getId(), "Listed")));
        arrayOfStudents.add(studentController.addStudent(
                new AddStudentRequest("Klopov", "Klop", "Klopovich", responseEntityGroup.getResp().getId(), "Unlisted")));

        //Чекнем ResponseEntity для студентов
        for(ResponseEntity<AddStudentResponse> response: arrayOfStudents){
            System.out.println("Id человечка: " + response.getResp().getId());
            System.out.println("Статус операции " + response.getStatus());
            System.out.println("А кто он такой-то ? Привет, я " +
                    storage.getStudents().get(response.getResp().getId()).getFirstName());
        }

        //Теперь для групп
        System.out.println("Id группы " + responseEntityGroup.getResp().getId());
        System.out.println("Статус операции " + responseEntityGroup.getStatus());
        System.out.println("А как называется то ? Ах... это же " +
                storage.getGroups().get(responseEntityGroup.getResp().getId()).getNameOfGroup());

    }

    //К моему превеликому сожалению в респонзе данной операции нет ни одного поля...
    // Хотя хотелось бы, чтобы выводило Student, чтобы в случае случайного удаления,
    // можно было из ResponseEntity его достать и восстановить!
    @Test
    public void checkDeletes(){
        StudentController studentController = new StudentController(storage);
        GroupController groupController = new GroupController(storage);
        //Удаляем 12L, 125L, "Kashov", "Max", "Lebedovich", "UnListed"
        ResponseEntity<DeleteStudentResponse>  responseStudent =
                studentController.deleteStudentById(new DeleteStudentRequest(12L));
        System.out.println("Статус операции " + responseStudent.getStatus());
        if(!storage.getStudents().containsKey(12L))
            System.out.println("Студента отчислили... плак плак");

        //Удаляем 136L, "MMB-104"
        ResponseEntity<DeleteGroupResponse> deleteGroupResponseResponseEntity =
                groupController.deleteGroup(new DeleteGroupRequest(136L));
        System.out.println("Статус операции " + deleteGroupResponseResponseEntity.getStatus());
        if(!storage.getGroups().containsKey(136L))
            System.out.println("Группу расформировали... плак плак");
    }

    //Давайте обновим данные студентишек и групп
    @Test
    public void checkUpdate(){
        StudentController studentController = new StudentController(storage);
        GroupController groupController = new GroupController(storage);

        //Обновим 12L, 125L, "Kashov", "Max", "Lebedovich", "UnListed"
        //   : на 12L, 125L, "Lakov", "Kirill", "Kavanovich", "Listed"

        ResponseEntity<EditStudentResponse> responseEntityStudent =
                studentController.editStudentById(
                        new EditStudentRequest(12L, "Kavanovich", "Lakov", "Kirill", 125L, "Listed"));
        System.out.println("Статус операции " + responseEntityStudent.getStatus());
        System.out.println("Теперь студента зовут " + studentController.getStudentById(
                new GetStudentByIdRequest(12L)).getResp().getFirstName());

        //Обновим 136L, "MMB-104"
        //  : на  136L, "HTB-101"

        ResponseEntity<EditGroupResponse> groupResponseResponseEntity =
                groupController.editGroup(
                        new EditGroupRequest(136L, "HTB-101"));
        System.out.println("Статус операции" + groupResponseResponseEntity.getStatus());
        System.out.println("Группу переименовали, теперь это " +
                groupController.getGroupById(new GetGroupByIdRequest(136L)).getResp().getNameOfGroup());
    }

    @Test
    public void checkGetStudentByGroup(){
        StudentController studentController = new StudentController(storage);
        ResponseEntity<GetStudentsByGroupResponse> responseEntity =
                studentController.getStudentsByGroup(new GetStudentsByGroupRequest(125L));
        for(Student student: responseEntity.getResp().getStudents()) {
            System.out.println("Статус операции " + responseEntity.getStatus());
            System.out.println("В группе под Id 125L есть студент под именем " + student.getFirstName());
        }
    }

    @Test
    public void checkErrors() {
        //Давайте-ка пройдемся по Id, которых нет и половим ошибки
        StudentController studentController = new StudentController(storage);
        GroupController groupController = new GroupController(storage);
        ResponseEntity<DeleteStudentResponse> responseEntityStudent =
                studentController.deleteStudentById(new DeleteStudentRequest(12532131L));
        ResponseEntity<DeleteGroupResponse> responseEntityGroup =
                groupController.deleteGroup(new DeleteGroupRequest(123124L));

        System.out.println("Мы хотели удалить группу, но " + responseEntityGroup.getErrors());
        System.out.println("Мы хотели удалить студента, но " + responseEntityStudent.getErrors());
    }

    @Test
    public void checkReadAll(){
        //Ну и напоследок проверим оставшуюся функцию readAll
        GroupService groupService = new GroupService(storage);
        StudentService studentService = new StudentService(storage);
        ArrayList<Student> students = studentService.readAll();
        ArrayList<Group> groups = groupService.readAll();
        System.out.println("Список всех студентов вуза: ");
        for(Student student: students)
            System.out.println("Студент: " + student.getFirstName());
        System.out.println("Список всех групп вуза: ");
        for(Group group: groups)
            System.out.println("Группа под названием: " + group.getNameOfGroup());
    }
}