package responses.lessons;

public class EditLessonResponse {
}
