package responses.lessons;

public class DeleteLessonResponse {
}
