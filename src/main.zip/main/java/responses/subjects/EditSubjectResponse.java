package responses.subjects;

public class EditSubjectResponse {
}
