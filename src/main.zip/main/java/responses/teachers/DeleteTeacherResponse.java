package responses.teachers;

public class DeleteTeacherResponse {
}
