package responses.teachers;

public class EditTeacherResponse {
}
