package responses.groups;

public class AddGroupResponse {

    private long id;

    public AddGroupResponse(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
