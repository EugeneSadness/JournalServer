package responses.groups;

public class DeleteGroupResponse {
}
