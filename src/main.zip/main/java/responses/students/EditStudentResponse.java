package responses.students;

public class EditStudentResponse {
}
