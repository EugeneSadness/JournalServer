package requests.subjects;

public class GetSubjectsRequest {
}
