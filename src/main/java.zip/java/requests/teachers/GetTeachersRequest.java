package requests.teachers;

public class GetTeachersRequest {

}
