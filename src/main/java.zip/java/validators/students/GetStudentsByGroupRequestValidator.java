package validators.students;

import requests.students.GetStudentsByGroupRequest;
import validators.Validator;
import validators.simple.StringValidator;
import java.util.ArrayList;
import java.util.List;

public class GetStudentsByGroupRequestValidator implements Validator<GetStudentsByGroupRequest> {

    @Override
    public List<String> validate(GetStudentsByGroupRequest req) {
        List<String > errors = new ArrayList<>();
        StringValidator.validate(req.getNameOfGroup(), errors, 20);
        return errors;
    }
}
