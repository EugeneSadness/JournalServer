package validators.teachers;

import validators.Validator;
import requests.students.EditStudentRequest;
import validators.simple.IdValidator;
import validators.simple.StringValidator;
import java.util.ArrayList;
import java.util.List;

public class EditTeacherRequestValidator implements Validator<EditStudentRequest> {

    private EditStudentRequest request;

    EditTeacherRequestValidator(EditStudentRequest request){}

    @Override
    public List<String> validate(EditStudentRequest req) {
        List<String> errors = new ArrayList<>();
        StringValidator.validate(request.getFirstName(), errors);
        StringValidator.validate(request.getMiddleName(), errors);
        StringValidator.validate(request.getLastName(), errors);
        IdValidator.validate(request.getId(), errors);
        return errors;
    }
}
