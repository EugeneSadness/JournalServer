package services.students;

import entities.Student;
import repositories.intefaces.IRepositoryStudent;

import java.util.List;

public interface IServiceStudent {

    public long create(long groupId, String firstName, String lastName, String middleName, String status);

    public Student read(long id);

    public void update(long id, Student student);

    public void delete(long id);

    public List<Student> readAll();

}
