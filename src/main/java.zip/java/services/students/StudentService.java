package services.students;

import entities.Student;
import repositories.StudentRepository;
import repositories.intefaces.IRepositoryStudent;
import java.util.List;

public class StudentService implements IServiceStudent {
    private StudentRepository studentRepository = new StudentRepository();

    public long create(long groupId, String firstName, String lastName, String middleName, String status) {
        return studentRepository.create(groupId, firstName, lastName, middleName, status);
    }

    public Student read(long id){
        return studentRepository.read(id);
    }

    public void update(long id, Student student) {
        studentRepository.update(student);
    }

    public void delete(long id){
        studentRepository.delete(id);
    }

    public List<Student> readAll() {
        return studentRepository.readAll();
    }
}
