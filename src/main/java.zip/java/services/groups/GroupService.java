package services.groups;

import entities.Group;
import repositories.GroupRepository;
import java.util.List;

public class GroupService implements IServiceGroup{
    GroupRepository groupRepository = new GroupRepository();

     public long create(String nameOfGroup){
         return groupRepository.create(nameOfGroup);
     }

    public Group read(long id){
          return groupRepository.read(id);
    }

    public void update(long id, String nameOfGroup){
         groupRepository.update(id, nameOfGroup);
    }

    public void delete(long id){
         groupRepository.delete(id);
    }

    public List<Group> readAll(){
         return groupRepository.readAll();
    }
}
