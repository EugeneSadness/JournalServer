package controllers.students;

import entities.Student;
import requests.students.*;
import responses.ResponseEntity;
import responses.students.*;
import services.students.StudentService;
import validators.students.*;
import java.util.List;

public class StudentController {
    private StudentService service = new StudentService();


    public ResponseEntity<AddStudentResponse> addStudent(AddStudentRequest request){
        int status;
        long id;
        List<String> errors;
        try {
            errors = new AddStudentsRequestValidator().validate(request);
            if (errors.isEmpty()) {
                Student student = new Student(request.getGroupId(), request.getFirstName(), request.getLastName(),
                        request.getMiddleName(), request.getStatus());
                id = service.create(request.getGroupId(), request.getFirstName(),
                        request.getLastName(), request.getMiddleName(), request.getStatus());
                status = 200;
                return new ResponseEntity<AddStudentResponse>(status, new AddStudentResponse(id));
            }
            System.out.println("return error status code");
            id = -1;
            status = 400;
            return new ResponseEntity<AddStudentResponse>(status, errors);
        }
        catch (Exception e){
            return new ResponseEntity<AddStudentResponse>(400, List.of("Some error happens!"));
        }
    }

    public ResponseEntity<GetStudentByIdResponse> getStudentById(GetStudentByIdRequest request){
        int status;
        List<String> errors;
        try {
            errors = new GetStudentByIdRequestValidator().validate(request);
            if (errors.isEmpty()) {
                Student student = service.read(request.getId());
                status = 200;
                return new ResponseEntity<GetStudentByIdResponse>(status, new GetStudentByIdResponse(
                        student.getFirstName(), student.getLastName(),
                        student.getMiddleName(), student.getStatus()));
            }
            System.out.println("return error status code");
            status = 400;
            return new ResponseEntity<GetStudentByIdResponse>(status, errors);
        }
        catch (Exception e){
            return new ResponseEntity<GetStudentByIdResponse>(400, List.of("Some error happens!"));
        }
    }

    public ResponseEntity<DeleteStudentResponse> deleteStudentById(DeleteStudentRequest request){
        int status;
        List<String> errors;
        try {
            errors = new DeleteStudentRequestValidator().validate(request);
            if (errors.isEmpty()) {
                service.read(request.getId());
                status = 200;
                return new ResponseEntity<DeleteStudentResponse>(status, new DeleteStudentResponse());
            }
            System.out.println("return error status code");
            status = 400;
            return new ResponseEntity<DeleteStudentResponse>(status, errors);
        }
        catch (Exception e){
            return new ResponseEntity<DeleteStudentResponse>(400, List.of("Some error happens!"));
        }
    }


    public ResponseEntity<EditStudentResponse> editStudentById(EditStudentRequest request){
        int status;
        List<String> errors;
        try {
            errors = new EditStudentRequestValidator().validate(request);
            if (errors.isEmpty()) {
                service.update(request.getId(), new Student(request.getId(),
                        request.getFirstName(), request.getLastName(),
                        request.getMiddleName() , request.getStatus()));
                status = 200;
                return new ResponseEntity<EditStudentResponse>(status, new EditStudentResponse());
            }
            System.out.println("return error status code");
            status = 400;
            return new ResponseEntity<EditStudentResponse>(status, errors);
        }
        catch (Exception e){
            return new ResponseEntity<EditStudentResponse>(400, List.of("Some error happens!"));
        }
    }
}
