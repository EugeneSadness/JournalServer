package repositories;

import entities.Student;
import repositories.intefaces.IRepositoryStudent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class StudentRepository implements IRepositoryStudent {
    Random random = new Random();

    @Override
    public long create(long groupId,String firstName, String lastName, String middleName, String status) {
        System.out.println("Student was created!");
        return random.nextLong();
    }

    @Override
    public Student read(long id) {
        System.out.println("Return student!");
        return new Student(random.nextLong(), random.nextLong(), "D", "D", "D", "D");
    }

    @Override
    public void update(Student student) {
        System.out.println("Student was updated!");
    }

    @Override
    public void delete(long id) {
        System.out.println("Student was deleted");
    }

    @Override
    public List<Student> readAll() {
        System.out.println("All students was got");
        return new ArrayList<Student>();
    }
}
