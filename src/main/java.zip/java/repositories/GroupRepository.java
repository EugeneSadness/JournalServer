package repositories;

import entities.Group;
import repositories.intefaces.IRepositoryGroup;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GroupRepository implements IRepositoryGroup {
    Random random = new Random();

    public long create(String nameOfGroup) {
        System.out.println("Creating group!");
        return random.nextLong();
    }

    public Group read(long id) {
        System.out.println("Reading group");
        return new Group(id, "Name of group in db");
    }

    public void update(long id, String nameOfGroup) {
        System.out.println("Editing the group");
    }

    public void delete(long id) {
        System.out.println("Group has deleted!");
    }

    public List<Group> readAll(){
        System.out.println("All groups was got!");
        return new ArrayList<Group>();
    }
}
