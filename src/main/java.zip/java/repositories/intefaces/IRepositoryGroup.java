package repositories.intefaces;

import entities.Group;

import java.util.List;

public interface IRepositoryGroup {

    public long create(String nameOfGroup);

    public Group read(long id);

    public void update(long id, String nameOfGroup);

    public void delete(long id);

    public List<Group> readAll();
}
