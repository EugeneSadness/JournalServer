package repositories.intefaces;

import entities.Student;
import java.util.List;

public interface IRepositoryStudent {

    public long create(long groupId,String firstName, String lastName, String middleName, String status);

    public Student read(long id);

    public void update(Student student);

    public void delete(long id);

    public List<Student> readAll();
}
