package responses.groups;

public class EditGroupResponse {

}
