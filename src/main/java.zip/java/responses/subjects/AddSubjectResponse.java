package responses.subjects;

public class AddSubjectResponse {

    private long id;

    public AddSubjectResponse(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
